package com.prog.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.prog.entity.Student;
import com.prog.service.StudentService;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;
 

@Controller
public class StudentController {
	
	
	@Autowired
	private StudentService studentService;
	

	@RequestMapping("/")
	public String home() {	

		return "index";
	}

	@RequestMapping("/assingment1")
	public String assingment1(Model m,HttpSession session) {
		List<Student>student =studentService.findAllBysn();
		/*
		 * session.removeAttribute("msg");
		 * 
		 * if(id.equals("1")) { session.setAttribute("msg",
		 * "Record Successfully Inserted!"); } if(id.equals("2")) {
		 * session.setAttribute("msg", "Record Successfully  !Deleted"); }
		 */
		  
		  
		m.addAttribute("student", student);
		m.addAttribute("session", session.getAttribute("msg"));
		System.out.println("=====================>"+student);

		return "assingment1";
	}

	@RequestMapping("/assingment2")
	public String assingment2() {

		return "assingment2";
	}
	
	@RequestMapping("/handler")
	public ModelAndView handler(String letter,String sentence,HttpSession session) {
		
		ModelAndView modelAndView = new ModelAndView();    
		modelAndView.setViewName("assingment2");	  
		
		//System.out.println(letter+"*******"+sentence);
		
		int pos=sentence.indexOf(letter);
		if(pos!=-1){
			pos=pos+letter.length();
			//session.setAttribute("msg", "  yes it is    Fount");
			session.removeAttribute("msg");
			session.removeAttribute("ERROR");
			
			session.setAttribute("msg",  sentence.substring(pos)  );
		    System.out.println( sentence.substring(pos) );	
		}else{
		    System.out.println(" Not Fount"   );
		    session.setAttribute("ERROR", "1");		
		}
			
		return modelAndView;
	}
	
	@RequestMapping("/database")
	public String staticDatabase() {

		return "database";
	}
	
	@RequestMapping("/DeleteByIdStudent")
	public String deleteByIdStudent(int id ) {		
		studentService.deleteByIdStudent(id);	
		 
		System.out.println("============Data Delete =====================");
		 return "redirect:assingment1";
		
	}
	@RequestMapping("/AddStudent")
	public String AddStudent(Student s ) {		
		Integer sn;
		 
		
		if(s.getSn()==1) {
			  sn = studentService.max();
			  if(sn<0) {
				  s.setSn(1000);
			  }else {
				  s.setSn(sn+1);
			  }
			  
			
		}
		else {
			
			sn = studentService.min();
			  if(sn<0) {
				  s.setSn(1000);
			  }else {
				  s.setSn(sn-1);
			  }
			
			   
			
		}		 
		 
		studentService.addStudent(s);
		
		System.out.println("============Data Add =====================");
		  
		 return "redirect:assingment1";
	}
	
	
	

	 
}
