package com.prog.repository;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.prog.entity.Student;

 
 

@Repository
public interface StudentRepository extends JpaRepository<Student, Integer>{
	
	
	@Query(value = "SELECT min(sn) FROM tbl_stuent")
	public Integer min();
	 
	@Query(value = "SELECT max(sn) FROM tbl_stuent")
	public Integer max();

	@Query(value = "SELECT * FROM tbl_stuent order By sn",nativeQuery=true)
	public List<Student>  findAllBysn();


}
