package com.prog.service;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.prog.entity.Student;
import com.prog.repository.StudentRepository;

 
@Service
public class StudentService {
	
	@Autowired
	private StudentRepository repo;
	
	
	 
	public void addStudent(Student e) {
		repo.save(e);
		
	}
	public List<Student> getAllStudent() {
		 return repo.findAll();
		
		 
	}
	
	public int deleteByIdStudent(int id) {
		repo.deleteById(id);
		 return 1;
		
		 
	}
	
	 
	public Integer min() {
		if(repo.min()!=null)
		return repo.min();
		
		return -1;
		
	}

	
	
	public  List<Student>  findAllBysn() {
		return repo.findAllBysn();
		  
	}
	 
	public Integer max() {
		if(repo.min()!=null)
		return repo.max();
		
		return -1;
	}
	
	
	 
	

}
