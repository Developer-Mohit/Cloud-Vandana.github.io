 
var myArray = [];
jQuery.get('/database', function(data) {
    database = JSON.parse(data);
});

var index = 0;

function resetIndex() {
    var i = 0;
    Array.prototype.slice.call(document.getElementById('tbl').rows).

    forEach(function(row) {
        row.childNodes[0].innerHTML = i++
    });

}

$(document).on('click', '.deleteBtn', function() {
	 
	$.get("/DeleteByIdStudent", { 'id' : this.id },function(data){
		window.location.href = 'assingment1';
		})
    
});
$(document).on('click', '#addFirst', function() {
    addStudent(2);
});


function addStudent(sn){	
		 
        let rand = Math.floor((Math.random() * database.length) );
        console.log("rand="+rand);
          $.post("AddStudent",
				    {
				      fname: database[rand].firstname,
				      city: database[rand].city,
				      lname:database[rand].lastname,
				      country:database[rand].country,
				      sn:sn				      
				    },
				    function(data,status){
			    	 	window.location.href="assingment1"
				    });
			
	
}



$(document).on('click', '#addLast', function() {
	  addStudent(1);
     
});

$(document).on('click', '#assingment1', function() {
$('.active').removeClass('active');
$("#includedContent").load("assingment1.html");
}
);

//------------Assigment-2 -----------------------
/*
$(document).on('click', '#assingment2', function() {
$("#includedContent").load("assignment2.html");
}
);
$(document).on('click', '#assingment2Btn', function() {
 Sentence=$("#Sentence").val();
 letter=$("#letter").val();
 $("#output").html("");
 let result = Sentence.indexOf(letter);

if(result!=-1){

;
 $("#output").html("<div class='text-success'>Success</div><div class='p-5 alert alert-success' role='alert'>"+Sentence.substring(result+1)+"</div>")

}else{
  $("#output").html("<div class='text-danger'>Not Found</div><div class='p-5 alert alert-danger' role='alert'>The letter does not exist in the sentence</div>");     
}



}
);*/



/*---------------Assigment-2 End---------------*/